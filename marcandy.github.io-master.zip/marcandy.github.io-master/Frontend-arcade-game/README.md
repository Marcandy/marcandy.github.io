frontend-nanodegree-arcade-game
===============================

#Description:

This is a project for the Udacity Front-End Web Dev Nanodgree. The goal is to create a classic arcage frogger game with technologies like Object Oriented JS and HTML5 Canvas.

##How to Play:

Open index.html in your browser to start playing.

Use the arrow keys to move the player across the board. Avoid colliding with the bugs. Reach the water to win.
